# SSP_generator
producing SSP form isochones.
