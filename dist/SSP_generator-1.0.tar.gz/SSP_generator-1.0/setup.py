from setuptools import setup, find_packages

setup(
    name = "SSP_generator",

    version = "1.0",

    packages = find_packages()
)
